const Discord = require("discord.js");
module.exports = {
   name: "",
   aliases: ["", "", ""],
   cooldowns: 3000,
   description: "",
   usage: "",
   toggleOff: false,
   developersOnly: false,
   userpermissions: ["ADMINISTRATOR", "VIEW_CHANNEL"],
   botpermissions: ["ADMINISTRATOR"],

   run: async (client, message, args) => {},
};
