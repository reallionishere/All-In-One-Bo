
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js")
const config = require("../../botconfig/main")
const client = require("../../index")
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.guild.me.permissionsIn(message.channel).has("SEND_MESSAGES"))
    return;


  // mentioned bot

  const prefixMention = new RegExp(`^<@!?${client.user.id}>( |)$`);
  if (message.content.match(prefixMention)) {

    let embed = new MessageEmbed()
      .setTitle(`${client.user.username} IS HERE!`)
      .setDescription(`**Hey!! ${message.author.username},**
        > <:x_heart:1326042136927539211> This Bot Is Develop By <@1264548743953256479>

        > <a:x_dot:1326083359688097813> Don't Know The Prefix: \`${config.prefix}\` 
        > <a:x_dot:1326083359688097813> If You Don't Know Where to Start Type :**${config.prefix}help**
        > <a:x_dot:1326083359688097813> If you continue to have problems [Click Here](https://discord.gg/2QDwvbn23X)
        > <a:x_dot:1326083359688097813> If Bot is not Responding Type : **${config.prefix}ping**`)
      .setThumbnail(client.user.displayAvatarURL())
      .setColor("#87CEEB")
      .setFooter(`Thanks For Using Me`)
    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setLabel("Youtube")

          .setStyle("LINK")
          .setEmoji("<:x_cold:1326042074147061822>")
          .setURL("https://www.youtube.com/@CODERX.NodeJS"),
        new MessageButton()
          .setLabel("Support Server")

          .setStyle("LINK")
          .setEmoji("<:x_world:1326042170041565247>")
          .setURL("https://discord.gg/2QDwvbn23X"),
        new MessageButton()
          .setLabel("Vote me")

          .setStyle("LINK")
          .setEmoji("<:x_member:1326042101179486370>")
          .setURL("https://youtube.com/@CODERX.NodeJS")
      )
    message.channel.send({ embeds: [embed], components: [row2] })

  }

})
