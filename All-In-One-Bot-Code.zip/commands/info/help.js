const { MessageActionRow, MessageButton, MessageSelectMenu, MessageEmbed } = require("discord.js")
const { version: discordjsVersion } = require("discord.js")
const config = require("../../botconfig/main")
module.exports = {
  name: "help",
  run: async (client, message, args) => {
    const row = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setCustomId('select')
          .setPlaceholder('CoderX Select Menu')

          .addOptions([
            {
              label: 'Main Menu',
              description: 'Shows the main menu',
              emoji: "<:x_home:1326042103809310822>",
              value: '0',
            },
            {
              label: 'Config Commands',
              description: 'Shows all the config commands',
              emoji: "<:x_setting:1326042069348909088>",
              value: '1',
            },

            {
              label: 'Fun Commands',
              description: 'Shows all the fun commands',
              emoji: "<:x_lol:1326042110176002070>",
              value: '3',
            },
            {
              label: 'Games Commands',
              description: 'Shows all the game commands',
              emoji: "<:x_games:1326042164932903016>",
              value: '4',
            },

            {
              label: 'Information Commands',
              description: 'Shows all the information commands',
              emoji: "<:x_info:1326042094284050494>",
              value: '5',
            },
            {
              label: 'Moderation Commands',
              description: 'Shows all the moderation commands',
              emoji: "<:x_mod:1326042091477794959>",
              value: '6',
            },
            {
              label: 'Coding Commands',
              description: 'Shows all the coding commands',
              emoji: "<:x_replit:1326042096930521139>",
              value: '8',
            },
            {
              label: 'Uptimer Commands',
              description: 'Shows all the uptimer commands',
              emoji: "<:x_diamond:1326042086910333090>",
              value: '9',
            },
            {
              label: 'Utility Commands',
              description: 'Shows all the utility commands',
              emoji: "<:x_devs:1326042098855575636>",
              value: '7',
            },
            {
              label: 'Image Commands',
              description: 'Shows all the image commands',
              emoji: "<:x_cold:1326042074147061822>",
              value: '10',
            },
            {
              label: 'Economy Commands',
              description: 'Shows all the economy commands',
              emoji: "<:x_galaxy:1326042132326256762>",
              value: '11',
            },
          ]),
      );
    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setLabel("Youtube")

          .setStyle("LINK")
          .setEmoji("<:x_cold:1326042074147061822>")
          .setURL("https://www.youtube.com/@CODERX.NodeJS"),
        new MessageButton()
          .setLabel("Support Server")

          .setStyle("LINK")
          .setEmoji("<:x_world:1326042170041565247>")
          .setURL("https://guns.lol/sujit_gfx"),
        new MessageButton()
          .setLabel("Vote me")

          .setStyle("LINK")
          .setEmoji("<:x_member:1326042101179486370>")
          .setURL("https://guns.lol/sujit_gfx")
      )

    const embed = new MessageEmbed()
      .setTitle("**HELP MENU**")
      .setDescription(`<:x_info:1326042094284050494> __**BOT INFO**__
> <a:x_dot:1326083359688097813>  Prefix: \` ${config.prefix}\`

<:x_mod:1326042091477794959> __**BOT'S COMMANDS**__
>  <a:x_dot:1326083359688097813> Config Commands
>  <a:x_dot:1326083359688097813> Fun Commands
>  <a:x_dot:1326083359688097813> Games Commands
>  <a:x_dot:1326083359688097813> Information Commands
>  <a:x_dot:1326083359688097813> Moderation Commands
>  <a:x_dot:1326083359688097813> Coding Commands
>  <a:x_dot:1326083359688097813> Uptimer Commands
>  <a:x_dot:1326083359688097813> Utility Commands
>  <a:x_dot:1326083359688097813> Image Commands
>  <a:x_dot:1326083359688097813> Economy Commands

<:x_members:1326042148763730084> __**BOT'S STATUS**__
> <a:x_dot:1326083359688097813> Current Ping  ${client.ws.ping}ms
> <a:x_dot:1326083359688097813> Discord.js Version: ${discordjsVersion}
> <a:x_dot:1326083359688097813> Running on Node ${process.version} on ${process.platform} ${process.arch}`)
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setColor("#87CEEB")


    let sendmsg = message.channel.send({ embeds: [embed], components: [row, row2] })

    let embed1 = new MessageEmbed()
      .setColor('#87CEEB')
      .setTitle('**HELP MENU**')
      .addFields(
        { name: "**CONFIG COMMANDS**", value: "`set-countingchannel`, `setwelcomechannel`, `setleavechannel`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 1')




    let embed3 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields(
        { name: "**FUN COMMANDS**", value: "`8ball`, `activity`, `pixelize`, `meme`" })
      .setColor("#87CEEB")
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setFooter('Page 3')

    let embed4 = new MessageEmbed()

      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields(
        { name: "**GAMES COMMANDS**", value: "`c4`, `tictactoe`, `roadrace`, `snake`, `quickclick`, `catchthefish`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 4')

    let embed5 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields(
        { name: "**INFO COMMANDS**", value: "`help`, `cmdhelp`, `botinfo`, `ping`, `invite`, `embed`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 5')

    let embed6 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields(
        { name: "**MOD COMMANDS**", value: "`ban`, `addroleall`, `removeroleall`, `softban`, `purge`, `mute`, `kick`, `tempmute`, `nuke` `stealemoji`" })
      .setFooter('Page 6')
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
    let embed8 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields(
        { name: "**Coding Commands**", value: "`Src`" })
      .setFooter('Page 8')
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
    let embed7 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields({ name: "**UTILITY COMMANDS**", value: "`addtag`, `edittag`, `removetag`, `afk`, `rolelist`, `snipe`, `timer`, `calculator`, `avatar`, `serverinfo`, `ss`, `dump`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 7')
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")

    let embed9 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields({ name: "**UPTIMER COMMANDS**", value: "`add-monitor`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 9')

    let embed11 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#87CEEB')
      .addFields({ name: "**ECONOMY COMMANDS**", value: "`balance`, `deposit`, `withdraw`, `search`, `shop`, `inv`, `pet`, `adopt`, `buy`, `sell`, `use`, `gamble`, `multi`, `beg`, `daily`, `fish`, `hunt`, `rob`, `rich` `postmeme`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 11')

    let embed10 = new MessageEmbed()
      .setTitle('**Help Menu**')
      .setColor('#FFFFFF')
      .addFields({ name: "**UTILITY COMMANDS**", value: "`anime`, `art`, `banner`, `cat`, `color`, `dog`, `gif`, `ss`" })
      .setImage("https://media.discordapp.net/attachments/1289040110725103627/1326380731118911529/standard_1.gif")
      .setColor("#87CEEB")
      .setFooter('Page 10')
    const filter = i => i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({
      filter,
      time: 40000000,
      componentType: "SELECT_MENU"
    });

    collector.on("collect", async (collected) => {
      const value = collected.values[0]
      if (value === "0") {
        collected.update({ embeds: [embed], components: [row, row2] })
      }
      if (value === "1") {
        collected.update({ embeds: [embed1], components: [row, row2] })
      }
      if (value === "3") {
        collected.update({ embeds: [embed3], components: [row, row2] })
      }
      if (value === "4") {
        collected.update({ embeds: [embed4], components: [row, row2] })
      }
      if (value === "5") {
        collected.update({ embeds: [embed5], components: [row, row2] })
      }
      if (value === "6") {
        collected.update({ embeds: [embed6], components: [row, row2] })
      }
      if (value === "8") {
        collected.update({ embeds: [embed8], components: [row, row2] })
      }
      if (value === "9") {
        collected.update({ embeds: [embed9], components: [row, row2] })
      }
      if (value === "7") {
        collected.update({ embeds: [embed7], components: [row, row2] })
      }
      if (value === "10") {
        collected.update({ embeds: [embed10], components: [row, row2] })
      }
      if (value === "11") {
        collected.update({ embeds: [embed11], components: [row, row2] })
      }
    })
  }
}