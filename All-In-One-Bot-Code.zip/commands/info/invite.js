const { MessageActionRow, MessageButton, MessageSelectMenu, MessageEmbed } = require("discord.js")

module.exports = {
  name: "invite",
  run: async (client, message, args) => {

    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setLabel("Youtube")

          .setStyle("LINK")
          .setEmoji("<:x_cold:1326042074147061822>")
          .setURL("https://www.youtube.com/@CODERX.NodeJS"),
        new MessageButton()
          .setLabel("Support Server")

          .setStyle("LINK")
          .setEmoji("<:x_world:1326042170041565247>")
          .setURL("https://www.youtube.com/@CODERX.NodeJS"),
        new MessageButton()
          .setLabel("Vote me")

          .setStyle("LINK")
          .setEmoji("<:x_member:1326042101179486370>")
          .setURL("https://www.youtube.com/@CoderX.NodeJS")
      )

    let embed = new MessageEmbed()
      .setTitle(`INVITE ME NOW `)
      .setURL("https://discord.com/oauth2/authorize?client_id=1325093279435460711")
      .setDescription(`Invite ${client.user.username} to your server`)
      .setFooter(client.user.tag, client.user.displayAvatarURL({ dynamic: true }))
      .setColor("#87CEEB")
      .setTimestamp()



    message.channel.send({ embeds: [embed], components: [row] })
  }
}